#include <rclcpp/rclcpp.hpp>
#include <trajectory_msgs/msg/joint_trajectory.hpp>
#include <trajectory_msgs/msg/joint_trajectory_point.hpp>

using namespace std::chrono_literals;

class PickPlaceLoop : public rclcpp::Node
{
public:
  PickPlaceLoop()
  : Node("pick_place_loop")
  {
    pub_ = this->create_publisher<trajectory_msgs::msg::JointTrajectory>("/arm_controller/joint_trajectory", 10);

    // Delay first publish a bit to let system startup properly
    timer_ = this->create_wall_timer(1s, [this]() {
      publish_trajectory();
      timer_->cancel();
      // Start repeating timer every 10s after first publish
      repeat_timer_ = this->create_wall_timer(10s, std::bind(&PickPlaceLoop::publish_trajectory, this));
    });
  }

private:
  void publish_trajectory()
  {
    RCLCPP_INFO(get_logger(), "Publishing pick and place trajectory...");

    trajectory_msgs::msg::JointTrajectory traj_msg;
    traj_msg.joint_names = {"1", "2", "3", "4", "5"}; // Double-check these names!

    std::vector<std::vector<double>> points = {
      {0.0, -0.3, 0.4, -0.3, 0.0},
      {0.0, -0.6, 0.4, -0.3, 0.0},
      {0.0, -0.6, 0.4, -0.3, 0.0},
      {0.0, -0.3, 0.4, -0.3, 0.0},
      {0.5, -0.3, 0.4, -0.3, 0.0},
      {0.5, -0.6, 0.4, -0.3, 0.0},
      {0.5, -0.6, 0.4, -0.3, 0.0},
      {0.5, -0.3, 0.4, -0.3, 0.0}
    };

    double time_sec = 0.0;
    for (const auto& pos : points)
    {
      trajectory_msgs::msg::JointTrajectoryPoint point;
      point.positions = pos;
      time_sec += 2.0;  // 2 seconds between points — try increasing delay for safety
      point.time_from_start = rclcpp::Duration::from_seconds(time_sec);
      traj_msg.points.push_back(point);
    }

    traj_msg.header.stamp = this->now();

    pub_->publish(traj_msg);

    RCLCPP_INFO(get_logger(), "Trajectory published with %zu points", traj_msg.points.size());
  }

  rclcpp::Publisher<trajectory_msgs::msg::JointTrajectory>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::TimerBase::SharedPtr repeat_timer_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<PickPlaceLoop>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
